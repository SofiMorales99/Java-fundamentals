public class MiPrimerPrograma {
    
    public static void main(String[] args) {
        String nombre = "Sofia";
        int edad = 23;
        String ciudad = "Adrogue";

        System.out.println("Mi nombre es "+ nombre);
        System.out.println("Tengo "+ edad +" anios");
        System.out.println("Vivo en "+ ciudad);
    }
}
